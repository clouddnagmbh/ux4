sap.ui.define([
	"com/sap/training/ux402/masterdetail/UX402_MasterDetailExercise/controller/BaseController"
], function (Controller) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.controller.Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		onInit: function () {
			this.getRouter().getRoute("carrierdetails").attachPatternMatched(this._onObjectMatched, this);
		},
		
		_onObjectMatched: function(oEvent){
			var sObjectPath = "/CarrierCollection('" + oEvent.getParameter("arguments").objectId + "')";
		/*	var sObjectPath = this.getOwnerComponent().getModel().createKey("/CarrierCollection", {
				AirLineID: oEvent.getParameter("arguments").objectId
			});*/
			this._bindView(sObjectPath);
		},
		
		_bindView: function(sObjectPath){
			var oView = this.getView();
			
			oView.bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function(){
						oView.setBusy(true);
					},
					dataReceived: function(){
						oView.setBusy(false);
					}
				}
			});
		},
		
		_onBindingChange: function(){
			var oView = this.getView();
			var oElementBinding = oView.getElementBinding();
			if(!oElementBinding.getBoundContext()){
				this.getRouter().getTargets().display("detailObjectNotFound");
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}
			var sPath = oElementBinding.getPath();
			this.getOwnerComponent().oListSelector.selectAListItem(sPath);
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});