jQuery.sap.declare("student00.com.sap.training.fullscreen.UX402_FullScreen.ZUX402CUSTCTR00Extension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "student00.com.sap.training.fullscreen.UX402_FullScreen",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/ZUX402CUSTCTR00"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.student00.com.sap.training.fullscreen.UX402_FullScreen.Component.extend(
	"student00.com.sap.training.fullscreen.UX402_FullScreen.ZUX402CUSTCTR00Extension.Component", {
		metadata: {
			manifest: "json"
		}
	});