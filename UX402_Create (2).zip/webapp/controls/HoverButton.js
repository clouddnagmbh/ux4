sap.ui.define([
	"sap/m/Button"
], function (Button) {
	"use strict";

	return Button.extend("student00.com.sap.training.fullscreen.UX402_FullScreen.controls.HoverButton", {
		
		metadata: {
			properties: {
				allowHover: {
					type: "boolean",
					defaultValue: false
				},
				hoverText: {
					type: "string"
				}
			},
			events: {
				hover: {}
			}
		},
		
		onmouseover: function(){
			if(this.getAllowHover()){
				this.fireHover();
			}
		},
		
		renderer: {}
		
	});
});