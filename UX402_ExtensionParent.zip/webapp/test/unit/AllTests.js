sap.ui.define([
	"student00/com/sap/training/fullscreen/UX402_FullScreen/test/unit/controller/Main.controller"
], function () {
	"use strict";
});