sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
], function (Controller, History, MessageToast) {
	"use strict";

	return Controller.extend("student00.com.sap.training.fullscreen.UX402_FullScreen.controller.Flights", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("Flights").attachPatternMatched(this._onObjectMatched, this);
		},
		
		_onObjectMatched: function(oEvent){
			var sId = oEvent.getParameters().arguments.carrierId;
			this._sCarrierId = sId;
			var oView = this.getView();
			
			oView.bindElement({
				path: "/CarrierCollection('" + this._sCarrierId + "')",
				events: {
					dataRequested: function(){
						oView.setBusy(true);
					},
					dataReceived: function(oEvent){
						oView.setBusy(false);
					}
					
				}
			});
		},
		
		onNavBack: function(){
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("Carrier", {}, true);
			}
		},
		
		onHover: function(evt){
			var sText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("msgSeatsAv", [evt.getSource().getHoverText()]);
			MessageToast.show(sText);
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.sap.training.ux402.fullscreen.UX402_FullScreenExercise.view.Flights
		 */
		//	onExit: function() {
		//
		//	}

	});

});